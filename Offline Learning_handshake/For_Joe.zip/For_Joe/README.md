Hey,
so I am sending you two folders for different trajectories.
in every folder you will find a bunch of .csv files and a subfolder.

1. the subfolder is what you need for the medaextra.ttt simulation to work, so inside it you can find the centers and the weights
2. of all .csv files that you can find theere you can use the _predictions to look at the PREDICTED trajectories from training by using the centers and weights from CPG_8.
3. the trajectories RECORDED from Coppelia are the ones tagged with _resampled40.